#!/bin/bash
# QuickJS Web Console Service - ES5 Compatible Version
# Optimized for BlackBerry 10 and older QNX browsers

echo "🚀 === QuickJS Web Console - ES5 Compatible ==="
echo "Modern ES2023 JavaScript Engine with ES5 Frontend"
echo "Optimized for BB10 and older QNX browsers"
echo ""

# Set up environment
export LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH
cd "$(dirname "$0")"

echo "✅ QuickJS Runtime: ES2023 features (backend)"
echo "✅ Web Interface: ES5 compatible (frontend)"  
echo "✅ BB10 Browser: Full compatibility guaranteed"
echo "✅ XMLHttpRequest: Instead of modern fetch()"
echo ""

echo "🌐 Starting ES5-compatible HTTP server on port 8080..."
echo "📱 BB10 Browser: http://[device-ip]:8080"
echo "💻 Desktop Browser: http://localhost:8080"
echo ""

echo "🔧 ES5 JavaScript Examples Ready:"
echo "   • Object methods: Object.keys({a:1, b:2})"
echo "   • Array functions: [1,2,3].map(function(x){return x*2})"
echo "   • Constructor functions: function Counter(){this.n=0}"
echo "   • Standard library: JSON.stringify(), new Date()"
echo ""

echo "Press Ctrl+C to stop the service"
echo "============================================"

# Start the ES5-compatible web console service
./bin/quickjs_web_console_es5 