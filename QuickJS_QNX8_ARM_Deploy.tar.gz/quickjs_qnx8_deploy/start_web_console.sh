#!/bin/bash
# QuickJS Web Console Service for QNX 8 ARM
# Based on proven JavaScriptCore console success pattern

echo "🚀 === QuickJS Web Console - QNX 8 ARM ==="
echo "Modern ES2023 JavaScript Engine with Web Interface"
echo "Following proven JavaScriptCore console pattern"
echo ""

# Set up environment
export LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH
cd "$(dirname "$0")"

echo "✅ QuickJS Runtime: ES2023 features enabled"
echo "✅ BigInt Support: Large number arithmetic"  
echo "✅ Classes & Modules: Modern JavaScript syntax"
echo "✅ Touch-Optimized: BB10 browser compatible"
echo ""

echo "🌐 Starting HTTP server on port 8080..."
echo "📱 Access from BB10 Browser: http://[device-ip]:8080"
echo "💻 Access from desktop: http://localhost:8080"
echo ""

echo "🔧 JavaScript Examples Ready:"
echo "   • Object manipulation: Object.keys({a:1, b:2})"
echo "   • Array operations: [1,2,3].map(x => x*2)"
echo "   • BigInt arithmetic: 123n * 456n"
echo "   • Classes: new Date(), JSON.stringify()"
echo ""

echo "Press Ctrl+C to stop the service"
echo "============================================"

# Start the web console service
./bin/quickjs_web_console 