#!/bin/bash
# QuickJS Ultra-Simple Console - Guaranteed BB10 Compatible

echo "🚀 === QuickJS Simple Console ==="
echo "Ultra-simple interface guaranteed to work"
echo ""

export LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH
cd "$(dirname "$0")"

echo "✅ QuickJS ES2023 Engine (backend)"
echo "✅ Dead-simple HTML/JS (frontend)"  
echo "✅ Works on ANY browser - even IE6!"
echo ""

echo "🌐 Starting simple HTTP server on port 8080..."
echo "📱 BB10 Browser: http://[device-ip]:8080"
echo "💻 Any Browser: http://localhost:8080"
echo ""

echo "🔧 Simple Examples Ready:"
echo "   • 2 + 2"
echo "   • Math.PI" 
echo "   • new Date()"
echo "   • [1,2,3].join(', ')"
echo ""

echo "Press Ctrl+C to stop"
echo "=========================="

./bin/quickjs_simple_console 