#!/bin/bash
# QuickJS QNX 8 ARM Deployment Package
echo "=== QuickJS QNX 8 ARM - Successfully Deployed ==="
echo "JavaScript Compiler: $(file bin/qjsc)"
echo "Static Library: $(ls -la lib/libquickjs.a)"
echo "Usage: ./bin/qjsc input.js -o output.c"

