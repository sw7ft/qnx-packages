XEYES FOR BLACKBERRY 10
=======================

This package contains the xeyes application and all its required libraries.

Requirements:
- An X server must be running on the BB10 device
- The DISPLAY environment variable must be set correctly

Installation:
1. Extract this package to a location on your BB10 device
2. Make sure run_xeyes.sh is executable (chmod +x run_xeyes.sh)
3. Run ./run_xeyes.sh

Troubleshooting:
- If xeyes fails to start, run ./check_libs.sh to see if any libraries are missing
- You may need to adjust the DISPLAY variable in run_xeyes.sh (default is :0)
- Make sure an X server is running on your device

