#!/bin/sh
# Script to run xeyes on BB10

# Get the script's directory (absolute path)
SCRIPT_DIR=$(dirname "$0")
SCRIPT_DIR=$(cd "$SCRIPT_DIR" && pwd)

# Set up the library path to find our shared libraries
export LD_LIBRARY_PATH="$SCRIPT_DIR/lib:$LD_LIBRARY_PATH"

# Set the DISPLAY environment variable - adjust as needed
export DISPLAY=:0

echo "Starting xeyes with:"
echo "LD_LIBRARY_PATH=$LD_LIBRARY_PATH"
echo "DISPLAY=$DISPLAY"

# List all libraries to verify they're present
echo "Available libraries:"
ls -la "$SCRIPT_DIR/lib/"

# Run xeyes with full path
"$SCRIPT_DIR/bin/xeyes"

# Exit status
exit_status=$?
echo "xeyes exited with status: $exit_status"
