#!/bin/sh
# Script to check library dependencies

# Get the script's directory
SCRIPT_DIR=$(dirname "$0")
SCRIPT_DIR=$(cd "$SCRIPT_DIR" && pwd)

# Set up the library path
export LD_LIBRARY_PATH="$SCRIPT_DIR/lib:$LD_LIBRARY_PATH"

echo "Running library dependency check for xeyes"
echo "LD_LIBRARY_PATH=$LD_LIBRARY_PATH"

# Try to use ldd if available
if command -v ldd >/dev/null 2>&1; then
    echo "Using ldd to check dependencies:"
    ldd "$SCRIPT_DIR/bin/xeyes"
else
    echo "ldd not available, listing libraries manually:"
    ls -la "$SCRIPT_DIR/lib/"
fi

echo "Done checking libraries"
