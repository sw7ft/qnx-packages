#!/bin/sh
# Script to run simple X11 app on BB10

# Get the script's directory (absolute path)
SCRIPT_DIR=$(dirname "$0")
SCRIPT_DIR=$(cd "$SCRIPT_DIR" && pwd)

# Set up the library path to find our shared libraries
export LD_LIBRARY_PATH="$SCRIPT_DIR/lib:$LD_LIBRARY_PATH"

# Set the DISPLAY environment variable - update with your X server IP
export DISPLAY=192.168.1.105:0

echo "Starting simple X11 app with:"
echo "LD_LIBRARY_PATH=$LD_LIBRARY_PATH"
echo "DISPLAY=$DISPLAY"

# Run app with full path
"$SCRIPT_DIR/bin/simple_x11"

# Exit status
exit_status=$?
echo "simple_x11 exited with status: $exit_status"
