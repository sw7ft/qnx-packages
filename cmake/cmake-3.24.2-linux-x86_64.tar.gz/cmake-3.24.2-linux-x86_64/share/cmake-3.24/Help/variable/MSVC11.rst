MSVC11
------

Discouraged.  Use the :variable:`MSVC_VERSION` variable instead.

``True`` when using the Microsoft Visual Studio ``v110`` toolset
(``cl`` version 17) or another compiler that simulates it.
