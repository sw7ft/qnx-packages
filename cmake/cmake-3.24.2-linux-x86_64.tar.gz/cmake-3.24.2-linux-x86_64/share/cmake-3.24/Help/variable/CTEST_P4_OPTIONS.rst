CTEST_P4_OPTIONS
----------------

.. versionadded:: 3.1

Specify the CTest ``P4Options`` setting
in a :manual:`ctest(1)` dashboard client script.
