<PROJECT-NAME>_BINARY_DIR
-------------------------

Top level binary directory for the named project.

A variable is created with the name used in the :command:`project` command,
and is the binary directory for the project.  This can be useful when
:command:`add_subdirectory` is used to connect several projects.
