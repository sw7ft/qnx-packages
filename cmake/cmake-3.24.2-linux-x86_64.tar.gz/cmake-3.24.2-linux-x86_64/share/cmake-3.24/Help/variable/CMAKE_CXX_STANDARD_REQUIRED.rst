CMAKE_CXX_STANDARD_REQUIRED
---------------------------

.. versionadded:: 3.1

Default value for :prop_tgt:`CXX_STANDARD_REQUIRED` target property if set when
a target is created.

See the :manual:`cmake-compile-features(7)` manual for information on
compile features and a list of supported compilers.
