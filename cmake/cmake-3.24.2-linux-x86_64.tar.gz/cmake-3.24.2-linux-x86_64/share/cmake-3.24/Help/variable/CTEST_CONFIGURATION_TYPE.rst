CTEST_CONFIGURATION_TYPE
------------------------

.. versionadded:: 3.1

Specify the CTest ``DefaultCTestConfigurationType`` setting
in a :manual:`ctest(1)` dashboard client script.

If the configuration type is set via ``-C <cfg>`` from the command line
then this variable is populated accordingly.
