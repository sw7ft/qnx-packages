CTEST_SCRIPT_DIRECTORY
----------------------

The directory containing the top-level CTest script.
The concept is similar to :variable:`CMAKE_SOURCE_DIR`.
