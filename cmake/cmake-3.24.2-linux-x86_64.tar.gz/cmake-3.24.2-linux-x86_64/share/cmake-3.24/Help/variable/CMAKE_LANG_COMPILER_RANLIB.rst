CMAKE_<LANG>_COMPILER_RANLIB
----------------------------

.. versionadded:: 3.9

A wrapper around ``ranlib`` adding the appropriate ``--plugin`` option for the
compiler.

See also :variable:`CMAKE_RANLIB`.
