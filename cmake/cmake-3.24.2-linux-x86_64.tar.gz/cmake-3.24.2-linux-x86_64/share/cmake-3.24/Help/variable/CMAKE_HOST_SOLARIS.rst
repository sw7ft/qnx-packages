CMAKE_HOST_SOLARIS
------------------

.. versionadded:: 3.6

``True`` for Oracle Solaris operating systems.

Set to ``true`` when the host system is Oracle Solaris.
